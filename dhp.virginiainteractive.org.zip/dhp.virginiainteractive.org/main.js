import puppeteer from 'puppeteer-extra';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
import * as cheerio from 'cheerio';
import { loadExistingRecords, saveRecord, loadState, saveState } from './src/utils/io.js';

// Apply stealth plugin to avoid Captchas
puppeteer.use(StealthPlugin());

const OCCUPATIONS = [
    'Veterinarian',
    'Veterinarian Faculty',
    'Veterinary Establishment - Ambulatory',
    'Veterinary Establishment - Stationary',
    'Veterinary Intern/Resident',
    'Veterinary Technician'
];

const STATES = [
    'Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut', 'Delaware', 
    'District of Columbia', 'Florida', 'Georgia', 'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 
    'Kansas', 'Kentucky', 'Louisiana', 'Maine', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota', 
    'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey', 'New Mexico', 
    'New York', 'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania', 'Rhode Island', 
    'South Carolina', 'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virginia', 'Washington', 
    'West Virginia', 'Wisconsin', 'Wyoming'
];

// Generate combinations: [''] (blank first), then 'Aa', 'Ab' ... 'Zz'
const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
const COMBINATIONS = ['']; 
for (let a of ALPHABET) {
    for (let b of ALPHABET) {
        COMBINATIONS.push(a + b.toLowerCase());
    }
}

async function runMasterScraper() {
    console.log("🚀 STARTING VIRGINIA STEALTH SCRAPER (V2)...");
    
    const existingRecords = loadExistingRecords();
    const stateTracker = loadState();
    
    let startOccIdx = stateTracker.occIdx;
    let startStateIdx = stateTracker.stateIdx;
    let startComboIdx = stateTracker.comboIdx;

    const browser = await puppeteer.launch({ 
        headless: false,
        args: ['--no-sandbox', '--disable-blink-features=AutomationControlled']
    });
    const page = await browser.newPage();

    try {
        for (let i = startOccIdx; i < OCCUPATIONS.length; i++) {
            const occupation = OCCUPATIONS[i];
            
            for (let j = (i === startOccIdx ? startStateIdx : 0); j < STATES.length; j++) {
                const targetState = STATES[j];
                
                console.log(`\n========================================`);
                console.log(`🎯 TARGET: ${occupation} | STATE: ${targetState}`);
                console.log(`========================================`);

                let k = (i === startOccIdx && j === startStateIdx) ? startComboIdx : 0;
                
                while (k < COMBINATIONS.length) {
                    const searchLetters = COMBINATIONS[k];
                    console.log(`\n🔤 Mode: ${searchLetters === '' ? 'BLANK STRIKE' : `DEEP DIVE (${searchLetters})`}`);

                    try {
                        // 1. Navigate to the main search page
                        await page.goto('https://dhp.virginiainteractive.org/Lookup/Index', { waitUntil: 'networkidle2' });
                        
                        // 2. Select Occupation
                        await page.evaluate((occ) => {
                            const select = document.querySelector('#OccupationId');
                            for (let opt = 0; opt < select.options.length; opt++) {
                                if (select.options[opt].text === occ) {
                                    select.selectedIndex = opt;
                                    select.dispatchEvent(new Event('change', { bubbles: true }));
                                    break;
                                }
                            }
                        }, occupation);
                        await new Promise(resolve => setTimeout(resolve, 1500));

                        // 3. Select State
                        await page.evaluate((st) => {
                            const select = document.querySelector('#State');
                            for (let opt = 0; opt < select.options.length; opt++) {
                                if (select.options[opt].text === st) {
                                    select.selectedIndex = opt;
                                    select.dispatchEvent(new Event('change', { bubbles: true }));
                                    break;
                                }
                            }
                        }, targetState);
                        await new Promise(resolve => setTimeout(resolve, 1000));

                        // 4. Input letters if in Deep Dive mode
                        if (searchLetters !== '') {
                            await page.evaluate((letters) => {
                                const parentForm = document.querySelector('#OccupationId').closest('form');
                                const lastNameInput = parentForm.querySelector('input[name="LastName"], input[name="LName"]');
                                if (lastNameInput) lastNameInput.value = letters;
                            }, searchLetters);
                        }

                        // 5. Click the Search Button
                        await page.evaluate(() => {
                            const parentForm = document.querySelector('#OccupationId').closest('form');
                            const searchBtn = parentForm.querySelector('input[type="submit"][value="Search"], button');
                            if (searchBtn) searchBtn.click();
                        });

                        await page.waitForNavigation({ waitUntil: 'networkidle2' });
                        
                        // 🛑 Check for CAPTCHA on main search
                        if (await page.$('iframe[src*="recaptcha"], iframe[src*="turnstile"], #cf-challenge-running')) {
                            console.log("🛑 CAPTCHA DETECTED ON SEARCH! Waiting 60 seconds for manual solve...");
                            await page.waitForNavigation({ timeout: 60000 }).catch(() => {});
                        }

                        const html = await page.content();
                        const $ = cheerio.load(html);

                        // Check if we hit the "Too many records" limit on the main search
                        if (html.toLowerCase().includes('too many records')) {
                            console.log(`   ⚠️ Limit Hit! Switching to Aa-Zz Deep Dive mode...`);
                            if (searchLetters === '') {
                                k = 1; 
                                continue; 
                            }
                        }

                        // Extract Profile Links
                        const profileLinks = [];
                        $('table tr').each((_, row) => {
                            const link = $(row).find('a').attr('href');
                            if (link && link.includes('/Lookup/Detail/')) {
                                profileLinks.push('https://dhp.virginiainteractive.org' + link);
                            }
                        });
                            
                        if (profileLinks.length > 0) {
                            console.log(`   📊 Found ${profileLinks.length} profiles. Engaging Stealth Spokes...`);

                            // Loop through each profile link
                            while (profileLinks.length > 0) {
                                const link = profileLinks.shift(); // Take the first link out of the array

                                if (existingRecords.has(link)) continue;

                                console.log(`      🕵️ Extracting: ${link.split('/').pop()}`);
                                const profilePage = await browser.newPage();
                                
                                try {
                                    await profilePage.goto(link, { waitUntil: 'domcontentloaded', timeout: 30000 });
                                    
                                    const profileHtml = await profilePage.content();

                                    // 🛑 ANTI-BAN DETECTION: Check if they IP-blocked us
                                    if (profileHtml.toLowerCase().includes("too many records")) {
                                        console.log("\n🛑 IP BAN DETECTED! Virginia blocked your IP.");
                                        console.log("👉 Please turn on your VPN or restart your router to get a new IP.");
                                        console.log("⏳ The script is paused. It will try again in 3 minutes...\n");
                                        await new Promise(res => setTimeout(res, 180000)); // Wait 3 minutes
                                        
                                        await profilePage.close();
                                        profileLinks.unshift(link); // Put the link back at the front of the line
                                        continue; 
                                    }

                                    // 🛑 Check for CAPTCHA on profile page
                                    if (await profilePage.$('iframe[src*="recaptcha"], iframe[src*="turnstile"]')) {
                                        console.log("      🛑 CAPTCHA ON PROFILE! Waiting 60s for you to click it...");
                                        await profilePage.waitForNavigation({ timeout: 60000 }).catch(() => {});
                                    }

                                    // Reload HTML in case captcha was solved
                                    const $$ = cheerio.load(await profilePage.content()); 
                                    
                                    // 🧹 ANTI-HONEYPOT CLEANER: Delete hidden garbage text
                                    $$('[style*="display:none"], [style*="display: none"], .hidden').remove();
                                    
                                    const record = {
                                        searchedState: targetState,
                                        name: "", licenseNumber: "", occupation: "", licenseStatus: "", 
                                        issueDate: "", expireDate: "", address: "", additionalPublicInformation: "",
                                        profileUrl: link, sourceUrl: link, scrapedAt: new Date().toISOString()
                                    };

                                    // 🎯 STRICT MAPPING
                                    $$('th, label, .detail-label, strong').each((_, el) => {
                                        let keyRaw = $$(el).text().replace(':', '').trim().toLowerCase();
                                        let val = $$(el).next('td, span, div').text().trim();
                                        if (!val) val = $$(el).parent().next('td, span, div').text().trim();
                                        
                                        if (val) {
                                            val = val.replace(/\s+/g, ' '); 
                                            if (keyRaw === 'name') record.name = val;
                                            else if (keyRaw.includes('license number')) record.licenseNumber = val;
                                            else if (keyRaw.includes('occupation')) record.occupation = val;
                                            else if (keyRaw.includes('status')) record.licenseStatus = val;
                                            else if (keyRaw.includes('issue') || keyRaw.includes('initial')) record.issueDate = val;
                                            else if (keyRaw.includes('expire')) record.expireDate = val;
                                            else if (keyRaw.includes('address')) record.address = val;
                                            else if (keyRaw.includes('public info')) record.additionalPublicInformation = val;
                                        }
                                    });

                                    // Only save if we actually got a name (prevents saving blank chunks if a page fails)
                                    if (record.name) {
                                        saveRecord(record);
                                        existingRecords.add(link);
                                    }
                                    
                                    // Dynamic delay (2 to 4 seconds) to prevent the IP ban from triggering as fast
                                    await new Promise(res => setTimeout(res, 2000 + Math.random() * 2000));
                                    
                                } catch (profileErr) {
                                    console.error(`      ❌ Failed profile: ${profileErr.message}`);
                                } finally {
                                    if (!profilePage.isClosed()) {
                                        await profilePage.close(); 
                                    }
                                }
                            }
                        } else {
                            console.log("   🤷‍♂️ No profiles found.");
                        }

                        // 💾 Save Progress
                        console.log(`✅ Finished combination. Saving state...`);
                        
                        if (searchLetters === '') {
                            k = COMBINATIONS.length; 
                        } else {
                            k++; 
                        }

                        let nextComboIdx = k, nextStateIdx = j, nextOccIdx = i;
                        if (nextComboIdx >= COMBINATIONS.length) {
                            nextComboIdx = 0; nextStateIdx++;
                            if (nextStateIdx >= STATES.length) { nextStateIdx = 0; nextOccIdx++; }
                        }
                        if (nextOccIdx < OCCUPATIONS.length) saveState(nextOccIdx, nextStateIdx, nextComboIdx);

                    } catch (err) {
                        console.error(`❌ Error processing combination:`, err.message);
                        k++; 
                    }
                }
            }
        }
    } catch (error) {
        console.error("❌ CRITICAL ERROR IN MASTER LOOP:", error.message);
    } finally {
        console.log("\n🏁 VIRGINIA SCRAPE COMPLETE.");
        await browser.close();
    }
}

runMasterScraper();